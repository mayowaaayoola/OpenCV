import cv2 as cv2

img1 = cv2.imread("C:\\Users\\padra\\Pictures\\Album from Workshop on Active Learning\\DON_3688.JPG")

cv2.imshow('ActiveLearning1', img1)

cv2.waitKey(0) 

